import boto3
import json
import cv2
import numpy as np
import os 
from django.conf import settings


path = 'C:/Python/project_blur/blur/AWS_results/results.json'
try:
	with open(path, 'r') as f:
		data = f.read()
		f.close() 
except FileNotFoundError as err:
	raise ValueError(f"File Not Found Error: {err}")
except Exception as err:
	raise ValueError(f"Results file saving to disk error: {err}") 

under_age_face_coords = list()
data = json.loads(data)

# Coordinates:
# Width, Height , Left, Top
IMG_WIDTH = 2560
IMG_HEIGHT = 1707

under_age_face_coords = []
cnt = 0
for i in range(len(data['FaceDetails'])):
	if (data['FaceDetails'][i]['AgeRange']['Low'] < 18):
		under_age_face_coords.append([])
		for v in data['FaceDetails'][i]['BoundingBox'].values():
			under_age_face_coords[cnt].append(v)
		cnt += 1

"""
The top and left values returned are ratios of the overall image size. For example, if the input image is 700x200 pixels, and the top-left coordinate of the bounding box is 350x50 pixels, the API returns a left value of 0.5 (350/700) and a top value of 0.25 (50/200).

The width and height values represent the dimensions of the bounding box as a ratio of the overall image dimension. For example, if the input image is 700x200 pixels, and the bounding box width is 70 pixels, the width returned is 0.1. 

X = IMG_WIDTH * values[2]
Y = IMG_HEIGHT * values[3]
W = IMG_WIDTH * values[0]
H = IMG_HEIGHT * values[1]
"""

# X, Y, W, H
under_age_face_rectangles = []

for i in range(len(under_age_face_coords)):
	under_age_face_rectangles.append([])
	under_age_face_rectangles[i].append(int(round(under_age_face_coords[i][2] * IMG_WIDTH, 0))) # X
	under_age_face_rectangles[i].append(int(round(under_age_face_coords[i][3] * IMG_WIDTH, 0))) # Y
	under_age_face_rectangles[i].append(int(round(under_age_face_coords[i][0] * IMG_WIDTH, 0))) # W
	under_age_face_rectangles[i].append(int(round(under_age_face_coords[i][1] * IMG_WIDTH, 0))) # H


for row in under_age_face_rectangles:
	print(row)