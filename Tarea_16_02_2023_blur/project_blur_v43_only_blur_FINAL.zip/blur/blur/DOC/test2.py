# from PIL import Image

# try:
# 	img = Image.open('C:/Python/project_blur/blur/media/images/0.jpg')
# except Exception as err:
# 	raise ValueError(f"Error {err}")

# # Image.size = Width, Height
# size = img.size

# print(size[0])

titles = ('0.jpg', '0_blurred_0.jpg', '1.jpg', '8.png', '0_blurred_1.jpg', '0_blurred_2.jpg', '0_blurred_2.jpg', '0_blurred_3.jpg')
new_title = '0_blurred_0.jpg'

cnt1 = new_title.count('blurred')
cnt2 = new_title.count('_')
count = 0

if cnt1 > 1:
	new_title = new_title.replace('blurred', '', cnt1-1)

if cnt2 > 2:
	new_title = new_title.replace('_', '', cnt2-2)

if cnt1 <= 0:
	s1, s2, s3 = new_title.rpartition(".")
	new_title = s1 + '_blurred_0' + s2 + s3
else:
	s1, s2, s3 = new_title.rpartition("_blurred_")
	s4, s5, s6 = s3.rpartition(".")
	new_title = s1 + '_blurred_' + str(0) + s5 + s6

while (new_title in titles):
	s1, s2, s3 = new_title.rpartition("_blurred_")
	s4, s5, s6 = s3.rpartition(".")
	new_title = s1 + '_blurred_' + str(count) + s5 + s6	
	count += 1

print("-------------")
print(new_title)
print("-------------")
