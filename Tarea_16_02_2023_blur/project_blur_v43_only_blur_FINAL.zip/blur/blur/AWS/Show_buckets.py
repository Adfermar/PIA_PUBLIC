# Shows all the aWS buckets
# LIBRARIES
import logging
import boto3
from botocore.exceptions import ClientError
import os
import json

# CONSTANTS
#---------------------------------

# PATH_CREDENTIALS = 'C:\Python\project_blur\blur\AWS\credentials.ini'
# os.environ['AWS_SHARED_CREDENTIALS_FILE'] = PATH_CREDENTIALS
# print(os.environ['AWS_SHARED_CREDENTIALS_FILE'])

#---------------------------------
# session = boto3.Session(
#     aws_access_key_id='ASIA25GWG45I6W53WY6W',
#     aws_secret_access_key='wvlkm1qTmRcU2int5I4sh6cBtvcMaFG00C+9oexo',
#     aws_session_token='FwoGZXIvYXdzEBIaDMh33w3alpJBOrF4jCLDAVqsQrR/G3NFvr3pqONEGU9eXxzd63KQ23PaGBOMxFfUxqMWV/PrrdkJTy4pTFBWgEzKZMYfas7hOXep0Sy46ZDqaKI3TbB70RZEODAweXwH75H4k9yTuRcJ5F8fRgtitgwhYFp7VzEqhOhMSgvJO9tyTGqzYVV0bgMEZGTf5PG9EHXLrTyiDKt+fzZyqN0g6JJa3fp6qfHWX8B3JPXAdED0ZfVAwehqSbrRo4bYeK/kB1KgF29ssVfJ4cY8wnBYKT363Cj3tdqeBjItXZ1ZoNnjho6dGIfM5oWejIFLY4qLtpgQroyyftUX7K3pfIW4hF+0gFwBYSlq',
# )


BUCKET = 'projectdjangofaces2233'

# Let's use Amazon S3
s3 = boto3.resource('s3')

# Print out bucket names
for bucket in s3.buckets.all():
    print(bucket.name)

# Show the content of an specific bucket:
bucket = s3.Bucket(BUCKET)
for obj in bucket.objects.all():
    print(obj.key)