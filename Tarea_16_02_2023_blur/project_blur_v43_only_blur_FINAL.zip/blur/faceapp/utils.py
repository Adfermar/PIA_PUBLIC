from django.http import HttpResponse
from django.http import Http404
from django.shortcuts import render
from django.shortcuts import redirect
from .models import Message, Image
from django.contrib import messages
from django.http import JsonResponse
from PIL import Image as PILimage
import boto3
import json
import cv2
import numpy as np
import os 
from django.conf import settings

# -------------------------------------------------------------------------------------------------------

def getKey(request, id):
    key = 0
    # Fetching the image key from the database
    try:
        key = request.POST.get(id)
    except IndexError:
        raise Http404(f"IndexError: Image key does not exists")
    except Exception as err:    
        raise Http404(f"Error: {err}")
    return key

# -------------------------------------------------------------------------------------------------------

def getImage(key):
    # Fetching the image from the database
    try:
        image = Image.objects.get(id = key)
    except IndexError:
        raise Http404(f"IndexError: Image object does not exists")
    except Image.DoesNotExist:
        raise Http404(f"DoesNotExist: Image object does not exists")
    except Exception as err:    
        raise Http404(f"Error: {err}")
    return image

# -------------------------------------------------------------------------------------------------------

def getData(request, field):
    # Fetching the form data
    try:
        data = json.loads(request.POST.get(field))
    except UnboundLocalError as err:
        raise ValueError('Can not retrieve {field}: {err}')
    except Exception as err:
        raise ValueError('<json.load> error: {err}')
    return data

# -------------------------------------------------------------------------------------------------------

def loadImage(img_url):
    # Open image file
    full_path = os.path.join(settings.MEDIA_ROOT, str(img_url))
    try:
        img_cv2 = cv2.imread(full_path)
    except Exception as err:
        raise ValueError('<Load image> error: {err}')
    return img_cv2

# -------------------------------------------------------------------------------------------------------

def resizeCV2image(img_cv2, height_size):
    # Resize image with fixed height and keeping width
    # aspect-ratio
    # Get the original aspect ratio
    aspect_ratio = img_cv2.shape[0] / img_cv2.shape[1]
    # Computing new width size
    new_height = height_size
    new_width = int(height_size / aspect_ratio)
    # Final image size
    size = (new_width, new_height)
    # Resize the image
    return cv2.resize(img_cv2, size, interpolation = cv2.INTER_LINEAR)

# -------------------------------------------------------------------------------------------------------

def applyBlur(img_cv2, x, y, w, h, sigma):
    try:
        # Setting the 'blur' parameters
        # Higher 'sigma' >> stronger blur
        ksize = (sigma * settings.BLUR_FACTOR)|1;
        # Extract the sub-region of the image corresponding to the rectangle
        roi = img_cv2[y:y+h, x:x+w]
        # Apply the Gaussian Blur on the sub-region and
        # replace the sub-region with the blurred version
        img_cv2[y:y+h, x:x+w] = cv2.GaussianBlur(roi, (ksize, ksize), sigma)
    except Exception as err:
        raise ValueError('<Blur> error: {err}')
    return img_cv2

# -------------------------------------------------------------------------------------------------------

def newTitle(images, image):

    titles = [img.title for img in images]
    new_title = image.title
    cnt1 = new_title.count('blurred')
    cnt2 = new_title.count('_')
    count = 0

    if cnt1 > 1:
        new_title = new_title.replace('blurred', '', cnt1-1)

    if cnt2 > 2:
        new_title = new_title.replace('_', '', cnt2-2)

    if cnt1 <= 0:
        s1, s2, s3 = new_title.rpartition(".")
        new_title = s1 + '_blurred_0' + s2 + s3
    else:
        s1, s2, s3 = new_title.rpartition("_blurred_")
        s4, s5, s6 = s3.rpartition(".")
        new_title = s1 + '_blurred_' + str(0) + s5 + s6

    while (new_title in titles):
        s1, s2, s3 = new_title.rpartition("_blurred_")
        s4, s5, s6 = s3.rpartition(".")
        new_title = s1 + '_blurred_' + str(count) + s5 + s6	
        count += 1

    return new_title

# -------------------------------------------------------------------------------------------------------

def saveImageToDisk(img_cv2, path):
    # Saving image to disk
    try:
        if not cv2.imwrite(path, img_cv2):
            raise ValueError('<cv2 image save> error')
    except Exception as err:
        raise ValueError('<Saving image to disk> error: {err}')   

# -------------------------------------------------------------------------------------------------------

def appendData(data, index, x, y, w, h):
    data.append([])
    data[index].append(x)
    data[index].append(y)
    data[index].append(w)
    data[index].append(h)
    return data

# -------------------------------------------------------------------------------------------------------

def fileExistsInBucket(my_bucket, image):
    # Checks if images exists in AWS bucket
    
    # Retrieve the list of existing buckets
    image_already_exists_in_bucket = False

    try:
        # Checks if images exists in AWS bucket
        for my_bucket in my_bucket.objects.all():
            if my_bucket.key == image.title: 
                image_already_exists_in_bucket = True
    except Exception as err:
        raise Http404(f"AWS LOGIN ERROR\nCHECK YOUR AWS-CREDENTIALS:\n{err}")
    
    return image_already_exists_in_bucket

# -------------------------------------------------------------------------------------------------------

def uploadFileToBucket(s3r, path, file_name, myBucket):
    # Upload file to AWS bucket
    try:
        s3r.Object(myBucket, file_name).upload_file(path)
    except FileNotFoundError as err:
        raise Http404(f"¡¡¡ FILE NOT FOUND !!! {err}")
    except Exception as err:
        raise Http404(f"Upload to AWS bucket error: {err}")

# -------------------------------------------------------------------------------------------------------

def detectFaces(myBucket, file_name):
    # Detect faces and write results to file
    try:
        rekog = boto3.client('rekognition')
        result = rekog.detect_faces(Image={'S3Object':{'Bucket':myBucket,'Name':file_name}},Attributes=['ALL'])
    except Exception as err:
        raise Http404(f"Rekognition error: {err}")
    return result

# -------------------------------------------------------------------------------------------------------

def writeFile(file, path):
    # Save file to hard disk
    try:
        with open(path, 'w') as f:
            f.write(json.dumps(file))
            f.close() 
    except FileNotFoundError as err:
        raise Http404(f"File Not Found Error: {err}")
    except Exception as err:
        raise Http404(f"Failed to save file: {err}")

# -------------------------------------------------------------------------------------------------------

def loadFile(path):
    # Load file to hard disk
    try:
        with open(path, 'r') as f:
            data = f.read()
            f.close()
    except FileNotFoundError as err:
        raise Http404(f"File Not Found Error: {err}")
    except Exception as err:
        raise Http404(f"Failed to load file: {err}")
    return json.loads(data)

# -------------------------------------------------------------------------------------------------------

def getUnderAgeFaces(data):
    # Returns the coordinates of under-age faces
    # Coordinates: Width, Height ,Left, Top
    under_age_faces = []
    cnt = 0
    for i in range(len(data['FaceDetails'])):
        if (data['FaceDetails'][i]['AgeRange']['Low'] < 18):
            under_age_faces.append([])
            for v in data['FaceDetails'][i]['BoundingBox'].values():
                under_age_faces[cnt].append(v)
            cnt += 1
    return under_age_faces

# -------------------------------------------------------------------------------------------------------

def transformCoordinates(input, img_width, img_height):
    # Transform face rectangles from AWS Rekognition format
    #   to Jcrop one
    # Input: list of coordinates from AWS Rekognition
    # Output: list of rectangles in JCROP format

    """
    Rekognition Format:
    --------------------
    The top and left values returned are ratios of the overall image size. 
    For example, if the input image is 700x200 pixels, 
    and the top-left coordinate of the bounding box is 350x50 pixels, 
    the API returns a left value of 0.5 (350/700) and a top value of 0.25 (50/200).

    The width and height values represent the dimensions of the bounding box 
    as a ratio of the overall image dimension. For example, if the input image is 700x200 pixels, 
    and the bounding box width is 70 pixels, the width returned is 0.1. 

    X = IMG_WIDTH * values[2]
    Y = IMG_HEIGHT * values[3]
    W = IMG_WIDTH * values[0]
    H = IMG_HEIGHT * values[1]

    Jcrop format:
    -------------
    X, Y, W, H
    """

    output = []

    if (img_width > 0) and (img_height > 0) and (len(input) > 0):

        for i in range(len(input)):
            output.append([])
            output[i].append(int(round(input[i][2] * img_width, 0)))    # X
            output[i].append(int(round(input[i][3] * img_height, 0)))   # Y
            output[i].append(int(round(input[i][0] * img_width, 0)))    # W
            output[i].append(int(round(input[i][1] * img_height, 0)))   # H

    return output

def getImageSize(path):
    # Open an PIL image and returns it width and height
    # Image.size = Width, Height

    try:
        img = PILimage.open(path)
    except FileNotFoundError as err:
        raise Http404(f"File Not Found Error: {err}")
    except Exception as err:
        raise Http404(f"Failed to load file: {err}")

    return img.size

# -------------------------------------------------------------------------------------------------------

def checkIfFileExists(images, name):
    # Returns True if image title exists in database
    # - - -
    # Create a list which contains all database image names
    titles = [img.title for img in images]
    flag_exists = False
    # Iterate over all database image titles
    for title in titles:
        if title == name:
            flag_exists = True
            break
    return flag_exists

# -------------------------------------------------------------------------------------------------------

def queryTitleExclude(sub_string):

    return Image.objects.exclude(title__icontains=sub_string)

# -------------------------------------------------------------------------------------------------------
