from . import views
from django.urls import path
from django.conf import settings
from django.conf.urls.static import static

app_name = 'faceApp'

urlpatterns = [
    path('', views.index, name='index'),
    path('show_select', views.show_select, name='show_select'),
    path('show_faces', views.show_faces, name = 'show_faces'),
    path('show_blur', views.show_blur, name = 'show_blur'),
    path('detect_select', views.detect_select, name='detect_select'),
    path('detect_faces', views.detect_faces, name='detect_faces'),
    path('detect_blur', views.detect_blur, name='detect_blur'),
    path('delete', views.delete, name='delete'),
    path('upload', views.upload, name = 'upload'),
]

if settings.DEBUG: 
    urlpatterns += static(
        settings.MEDIA_URL, 
        document_root = settings.MEDIA_ROOT
    )