// ---------------------------------------------------------------------------

function create_jcrop(jcrop, x, y, w, h) {

	// Setting a default jcrop window
	const rect = Jcrop.Rect.create(x, y, w, h);
	jcrop.newWidget(rect, options);	

  }

// ---------------------------------------------------------------------------