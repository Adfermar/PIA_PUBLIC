function showInfo(links, display) {

	for (var i = 0; i < links.length; i++) {
		links[i].addEventListener("mouseover", function (event) {
			switch (event.target.innerHTML) {
			case "Show images":
				display.innerHTML = "Select and<br>displays an image.<br>You can also<br>apply 'blur'effect<br>to it.";
				break;
			case "Select image":
				display.innerHTML = "Select an image<br>to detect<br>under-age faces<br>and apply 'blur'<br>effect.";
				break;
			case "Delete images":
				display.innerHTML = "Select an image<br>and remove it<br>from database<br>and hard disk.";
				break;
			case "Upload images":
				display.innerHTML = "Upload new<br>images.";
				break;
			default:
				display.innerHTML = "";
				break;
			}
			display.style.display = "block";
		});
		links[i].addEventListener("mouseout", function (event) {
			// display.style.display = "none";
			display.innerHTML = "Move mouse<br> over link to show<br> more info.";
		});
	}
}