
// ---------------------------------------------------------------------------

function createJcrop(id_img) {

	target = document.getElementById(id_img);

	// Create Jcrop object
	const options = { multi: true, shade: true, shadeColor: 'green' };
	let jcrop = Jcrop.attach(id_img, options);	
	
	return jcrop;
  }

// ---------------------------------------------------------------------------

function showCoord(jcrop) {
		
		const node = document.getElementById('table');
		while (node.lastElementChild) {
			node.removeChild(node.lastElementChild);
		}
		createTableRow('table', 'r0', '');
		createTableCell('r0', 'Crop nº', 'th', 'first_col');
		createTableCell('r0', 'Coordinates', 'th', 'second_col');	

		let counter = 1;
		let coordinates_active = '';
		// Show all Jcrop rectangle coordinates in browser terminal
		for (let c of jcrop.crops) {

			const coordinates = 
			' x:' + Math.round(c.pos.x) + 
			' y:' + Math.round(c.pos.y) + 
			' w:' + Math.round(c.pos.w) + 
			' h:' + Math.round(c.pos.h);
			
			// Add a row in table which contains the last Jcrop rectangle coordinates
			const row_id = 'r' + counter;
			createTableRow('table', row_id, '');
			createTableCell(row_id, counter, 'td', '');
			createTableCell(row_id, coordinates, 'td', '');	
			
			counter++;
		
		}
}

// ---------------------------------------------------------------------------

function alertMessage(text) {
	// Showing an emergent windows with a message
	alert(text)
}

// ---------------------------------------------------------------------------

function removeAllelements(tag) {
	// Removing all table rows
	let elements = document.getElementsByTagName(tag);
	for (let i = 0; i < elements.length; i++) {
		document.removeChild(elements[i]);
	}
}

// ---------------------------------------------------------------------------

function getCoord(jcrop) {
	const data = [];
	for (let c of jcrop.crops) {
		data.push([Math.round(c.pos.x) , Math.round(c.pos.y), Math.round(c.pos.w), Math.round(c.pos.h)]);
	}
	return JSON.stringify(data);
}

// ---------------------------------------------------------------------------

function createTableCell(row_id, text, type, node_class) {
	const row = document.getElementById(row_id);
	const cell = document.createElement(type);
	const text_node = document.createTextNode(text);
	cell.class = node_class;
	cell.appendChild(text_node);
	row.appendChild(cell);
}  

// ---------------------------------------------------------------------------

function createTableRow(table_id, new_row_id, node_class) {
	let table = document.getElementById(table_id);
	let new_row = document.createElement("tr");
	new_row.id = new_row_id;
	new_row.class = node_class;
	table.appendChild(new_row);
}  

// ---------------------------------------------------------------------------

function transformCoordinates(
	old_coord, 
	original_width, 
	original_height,
	resized_width,
	resized_height,
	) {

    // Resize image with fixed height and keeping width aspect-ratio
    // Get the original aspect ratio
	let new_coord = [];

	for (let i in old_coord) {
		
		let array = [];
		
		array.push((Math.round(resized_width * old_coord[i][0])/original_width));
		array.push((Math.round(resized_height * old_coord[i][1])/original_height));
		array.push((Math.round(resized_width * old_coord[i][2])/original_width));
		array.push((Math.round(resized_width * old_coord[i][3])/original_width));

		new_coord.push(array);

	}

	return new_coord;

}

// ---------------------------------------------------------------------------