// ---------------------------------------------------------------------------

function showImg() {
	/* Shows the image selected through <input="file"> tag */
		// Getting the files selected by <input file> tag
		var file = document.getElementById('file').files[0];
		// Creating a FileReader object
		var reader  = new FileReader();
		// After creating object then execute the following code:
		reader.onload = function(e)  {
			var image = document.createElement("img");
			// the result image data
			image.src = e.target.result;
			// Create a class attribute:
			const att = document.createAttribute("class");
			// Setting the new attibute
			att.value = "image";
			// Add the class attribute to the image element:
			image.setAttributeNode(att);
			// Getting the div element which contains the image to show
			//------------------------------------------------
			console.log("File selected:", image);
			//------------------------------------------------
			var div = document.getElementById('div_image');
			// Checking if there is an image tag
			// created in <div> element
			if (div.hasChildNodes()) {
				// Replacing the first image found by a new one
				div.replaceChild(image, div.children[0]);
				
			 } else {
				// Adding a new image element attached to <div> container
				document.getElementById('div_image').appendChild(image);
			}
		}
		// Declaring the file loader
		reader.readAsDataURL(file);
	}

	// ---------------------------------------------------------------------------