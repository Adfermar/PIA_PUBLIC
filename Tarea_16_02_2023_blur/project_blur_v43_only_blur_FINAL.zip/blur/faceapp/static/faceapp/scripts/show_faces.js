
// ---------------------------------------------------------------------------

function createJcrop(id_img) {

	target = document.getElementById(id_img);

	// Create Jcrop object
	const options = { multi: true, shade: true, shadeColor: 'green' };
	let jcrop = Jcrop.attach(id_img, options);

	// Setting a default jcrop window
	// const rect = Jcrop.Rect.create(x, y, w, h);
	// jcrop.newWidget(rect, options);	
	
	return jcrop;
  }

// ---------------------------------------------------------------------------

function showCoordAtRectChanges(jcrop) {

	jcrop.listen('crop.change', (widget, event) => {
		
		const node = document.getElementById('table');
		while (node.lastElementChild) {
			node.removeChild(node.lastElementChild);
		}
		createTableRow('table', 'r0', '');
		createTableCell('r0', 'Crop nº', 'th', 'first_col');
		createTableCell('r0', 'Coordinates', 'th', 'second_col');	
		
		// removeAllelements('table');
		// // let table = document.getElementById('table');
		// // table.removeAllelements;
		// let rows = document.getElementsByTagName('tr');
		// // let row = document.getElementsByClassName('row');
		// // if (row.length > 0) {
		// for (let r in rows) {
		// 	// row.removeAllelements();
		// 	// table.removeChild(row[i]);
		// 	// alertMessage(i);
		// 	r.removeAllelements;
		// }
		// // }
		// // table.removeChild(row);

		let counter = 1;
		let coordinates_active = '';
		// Show all Jcrop rectangle coordinates in browser terminal
		for (let c of jcrop.crops) {
			


			const coordinates = 'x:' + c.pos.x + ' y:' + c.pos.y + ' w:' + c.pos.w + ' h:' + c.pos.h;
			// console.log(counter + '>>' + coordinates);
		
			// coordinates_active = 'x:' + jcrop.active.pos.x + ' y:' + jcrop.active.pos.y + ' w:' + jcrop.active.pos.w + ' h:' + jcrop.active.pos.h;
			
			// Add a row in table which contains the last Jcrop rectangle coordinates
			const row_id = 'r' + counter;
			console.log(row_id);
			createTableRow('table', row_id, '');
			createTableCell(row_id, counter, 'td', '');
			createTableCell(row_id, coordinates, 'td', '');	
			
			counter++;
		
		}

	});

}

// ---------------------------------------------------------------------------

function alertMessage(text) {
	// Showing an emergent windows with a message
	alert(text)
}

// ---------------------------------------------------------------------------

function removeAllelements(tag) {
	// Removing all table rows
	let elements = document.getElementsByTagName(tag);
	for (let i = 0; i < elements.length; i++) {
		document.removeChild(elements[i]);
	}
}

// ---------------------------------------------------------------------------

function getCoord(jcrop) {
	const data = [];
	for (let c of jcrop.crops) {
		data.push([c.pos.x , c.pos.y, c.pos.w, c.pos.h]);
	}
	return JSON.stringify(data);
}

// ---------------------------------------------------------------------------

function createTableCell(row_id, text, type, node_class) {
	const row = document.getElementById(row_id);
	const cell = document.createElement(type);
	const text_node = document.createTextNode(text);
	cell.class = node_class;
	cell.appendChild(text_node);
	row.appendChild(cell);
}  

// ---------------------------------------------------------------------------

function createTableRow(table_id, new_row_id, node_class) {
	let table = document.getElementById(table_id);
	let new_row = document.createElement("tr");
	new_row.id = new_row_id;
	new_row.class = node_class;
	table.appendChild(new_row);
}  

// ---------------------------------------------------------------------------

function writeCoordAtCropChanges(jcrop) {
	
	var counter = 0;
	jcrop.listen('crop.change', (widget, event) => {
		counter++;
		// Show all Jcrop rectangle coordinates in browser terminal
		const coordinates = '_x:' + c.pos.x + '_y:' + c.pos.y + '_w:' + c.pos.w + '_h:' + c.pos.h;
		for (let c of jcrop.crops) {
			console.log(counter + '>>' + coordinates);
		}
		// Add a row in table which contains the last Jcrop rectangle coordinates
		createTableRow(coordinates);
	});
}


// ---------------------------------------------------------------------------

// ---------------------------------------------------------------------------

// ---------------------------------------------------------------------------

// ---------------------------------------------------------------------------

// ---------------------------------------------------------------------------

// ---------------------------------------------------------------------------
/* UNUSED 

function send_coord(data, url) {

	$(document).ready(function() {
		// Send coordenates by clicking 'send' button
		$('#submit-button').click(function(e) {
			
			// prevent the form from submitting
			e.preventDefault();  
			
			// Creating data to be sent
			var data_to_send = {'coord': data};
			
			// Activate CSRF protection
			const csrftoken = document.querySelector('[name=csrfmiddlewaretoken]').value;
			
			// Send coords through 'ajax' libraries
			$.ajax({
				type: "POST",
				url: url,
				data: data_to_send,
				// Include CSRF token in AJAX request
				headers: {'X-CSRFToken': csrftoken},
				// If data was setn sucessfully
				// then show the server response
				// by console
				success: function(response) {
					console.log('Data sent OK.', data_to_send);
				},
			});
		});
	});

}

// ---------------------------------------------------------------------------

function create_coord_chain(x, y, w, h) {

	return coord = '{ ' +
		'x:' + x + '; ' +
		'y:' + y + '; ' +
		'h:' + h + '; ' +
		'w:' + w + '; ' +
	'}';
}

*/