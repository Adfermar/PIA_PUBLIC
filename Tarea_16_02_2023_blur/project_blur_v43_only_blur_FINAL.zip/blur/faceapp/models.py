from django.db import models
from django.urls import reverse

# Create your models here.

class Message(models.Model):
    message_text = models.CharField(max_length=200)

class Image(models.Model):
    title = models.CharField(max_length = 200)
    uploadedImg = models.ImageField(upload_to = "images/")