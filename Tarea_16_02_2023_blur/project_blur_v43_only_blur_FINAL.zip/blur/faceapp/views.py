from django.http import HttpResponse
from django.http import Http404
from django.shortcuts import render
from django.shortcuts import redirect
from .models import Message, Image
from django.contrib import messages
from django.http import JsonResponse
from PIL import Image as PILimage
import boto3
import json
import cv2
import numpy as np
import os 
from django.conf import settings
# ================
from . import utils

# -------------------------------------------------------------------------------------------------------

def index(request):

    return render(request, 'index.html')

# -------------------------------------------------------------------------------------------------------

def show_select(request):

    # Return all database images
    try:
        images = Image.objects.all()
    except Image.DoesNotExist:
        raise Http404(f"There is no images")        
    return render(request, 'show_select.html', context = {'images': images})

# -------------------------------------------------------------------------------------------------------

def delete(request):
    
    key = 1
    removedImgTitle = ''
    if request.method == "POST":
        # Fetching the key of the image 
        # that will be wiped 
        images = Image.objects.all()
        if images.exists():
            # Fetching the key of the image to be deleted
            key = utils.getKey(request, 'img_id')
            # Fetching the image from the database
            try:
                image = Image.objects.get(id = key)
            except IndexError:
                raise Http404(f"IndexError: Image object does not exists")
            except Image.DoesNotExist:
                raise Http404(f"DoesNotExist: Image object does not exists")
            except Exception as err:    
                raise Http404(f"Error: {err}")
            # Getting image title before removing it
            removedImgTitle = Image.objects.get(id = key).title
            # Deleting the image from the database
            image.delete()
            # Delete image from disk
            path = os.path.join(settings.MEDIA_ROOT, str(image.uploadedImg))
            if os.path.exists(path):
                os.remove(path)
            else:
                raise ValueError(f"Could not delete: {removedImgTitle}")
            # Check if there is a '.json' file attached to image and trying to remove it
            path = settings.AWS_RESULTS_FOLDER + image.title + '.json'           
            if os.path.exists(path):
                os.remove(path)
                messages.success(request, "Image and JSON files #_%s_# deleted from database and hard disk" % removedImgTitle )
            else:
                messages.success(request, "Image #_%s_# deleted from database and hard disk" % removedImgTitle )          
            # return HttpResponse(f"The image: {key} has been removed.") # For debugging purposes
            return redirect('faceApp:index')
        else:
            # return HttpResponse(f"No images to show") # For debugging purposes
            return redirect('faceApp:index')
    else:
        # Fetching all images from database
        images = Image.objects.all()
        return render(
                        request, 
                        'delete.html',
                        context = {'images': images, 'removedImgTitle':removedImgTitle}
                    )

# -------------------------------------------------------------------------------------------------------

def upload(request):

    if request.method == "POST":
        # Fetching the form data
        try:
            uploadedImg = request.FILES["uploadedImg"]
            new_title = uploadedImg.name
        except NameError:
            raise Http404("ERROR: Wrong image name")
        except Exception as err:
            raise Http404(f'NOTHING TO SEND. Pick an image file!!! \n>> {err}')
        # 
        images = Image.objects.all()
        if images.exists():        
            if utils.checkIfFileExists(images, new_title):
                raise Http404("ERROR: DUPLICATE FILES NOT ALLOWED!!!")
        # ImageField Object (from Django Models)
        image = Image(title = new_title, uploadedImg = uploadedImg)        
        # Saving the information in the database
        try:
            image.save()
            messages.success(request, "Image  #_%s_# uploaded" % new_title )
            return redirect('faceApp:index')
        except Exception as err:
            raise Http404(f"ERROR: {err}")
    return render(request, "upload.html")

# -------------------------------------------------------------------------------------------------------

def show_faces(request):

    # The form was used: send selected image to 'faces' view
    if request.method == "POST":
        try:
            # Fetching the key of the image
            key = utils.getKey(request, 'img_id')
        except Exception as err:
            raise Http404(f"Cannot obtain image ID: {err}")
        try:
            # Fetching the image from the database
            image = utils.getImage(key)
        except Image.DoesNotExist:
            raise Http404(f"Image does not exists")
        return render(request, 'show_faces.html', context = {'image': image})
    else:
        raise Http404(f"Unknown error")

# -------------------------------------------------------------------------------------------------------

def show_blur(request):

    data = list()
    if request.method == "POST":
        # Check if there is any image in DB
        images = Image.objects.all()
        # image = Image.objects.first()
        if images.exists():
            # Fetching the key of the image
            key = utils.getKey(request, 'img_id')
            # ---------------------------------------------------
            # Fetching the image from the database
            image = utils.getImage(key)
            # ---------------------------------------------------
            # Fetching the form data
            data = utils.getData(request, 'coordinate')
            # ---------------------------------------------------
            # Open image file
            img_cv2 = utils.loadImage(image.uploadedImg)
            # ---------------------------------------------------
            # Resize image with fixed height and keeping width
            # aspect-ratio
            img_cv2 = utils.resizeCV2image(img_cv2, 500)
            # ---------------------------------------------------
            try:
                # Setting the coordinate data to send
                data_to_send = []
                # Iterating over each crop coordinates
                for i in range(len(data)):
                    # Getting the rectangle data
                    x, y, w, h = [j for j in data[i]]
                    utils.appendData(data_to_send, i, x, y, w, h)
                    # Setting the 'blur' parameters
                    # Higher 'sigma' >> stronger blur
                    img_cv2 = utils.applyBlur(img_cv2, x, y, w, h, settings.BLUR_SIGMA)
            except Exception as err:
                raise ValueError('<Blur iteration> error: {err}')
            # ---------------------------------------------------
            # Append the '_blurred' subfix to modified image title
            new_title = utils.newTitle(images, image)
            path = os.path.join(settings.MEDIA_ROOT, 'images/' + new_title)
            # Saving the information into the database
            image_blurred = Image(title = new_title, uploadedImg = 'images/' + new_title)
            image_blurred.save()
            # ---------------------------------------------------
            # Saving image to disk
            utils.saveImageToDisk(img_cv2, path)
            # ---------------------------------------------------
            # Render coords. data plus image
            return render(request, 'show_blur.html', context = {"data": data_to_send, "image": image_blurred})
            # ---------------------------------------------------

            # ---------------------------------------------------
            # Show a message: for debugging only
            # messages.success(request, "<< %s >>" % data_to_send)
            # # Redirect to 'index' only for debugging purpose
            # return redirect('faceApp:index')
            # ---------------------------------------------------
        else:
            raise Http404(f"Error: image not found")
    # Got to the index web and show an error message
    messages.error(request, "POST data error")
    return redirect('faceApp:index')

# -------------------------------------------------------------------------------------------------------

def detect_select(request):

    # Return all database images
    try:
        # images = Image.objects.all()
        images = utils.queryTitleExclude('blurred')
    except Image.DoesNotExist:
        raise Http404(f"There is no images")        
    return render(request, 'detect_select.html', context = {'images': images})

# -------------------------------------------------------------------------------------------------------

def detect_faces(request):

    data = list()
    if request.method == "POST":
        # Check if there is any image in DB
        images = Image.objects.all()
        if images.exists():
            # ---------------------------------------------------
            # Fetching the key of the image
            key = utils.getKey(request, 'img_id')
            # ---------------------------------------------------
            # Fetching the image from the database
            image = utils.getImage(key)
            # ---------------------------------------------------
            # Boto3 S3 Object declaration
            try:
                s3c = boto3.client('s3')
                s3r = boto3.resource('s3')
            except Exception as err:
                raise Http404(f"AWS CLIENT ERROR\nAWS RESOURCE ERROR:\n{err}")
            # ---------------------------------------------------
            # Check if file exists in Bucket
            my_bucket = s3r.Bucket(settings.BUCKET)
            if not utils.fileExistsInBucket(my_bucket, image):
                # ---------------------------------------------------            
                # Upload image to AWS bucket
                path = os.path.join(settings.MEDIA_ROOT, 'images/' + image.title)
                utils.uploadFileToBucket(s3r, path, image.title, settings.BUCKET)            
                # ---------------------------------------------------
                # Detect faces and write results to file
                file = utils.detectFaces(settings.BUCKET, image.title)            
                # ---------------------------------------------------
                # Save file to hard disk
                path = settings.AWS_RESULTS_FOLDER + image.title + '.json'
                utils.writeFile(file, path)
            # END IF
            # ---------------------------------------------------
            # Load AWS Rekognition result file from disk
            path = settings.AWS_RESULTS_FOLDER + image.title + '.json'
            data = utils.loadFile(path)
            # ---------------------------------------------------
            # Returns the coordinates of under-age faces
            rekog_faces = utils.getUnderAgeFaces(data)
            if len(rekog_faces) > 0:
                # ---------------------------------------------------
                # Get the image size (width and height)  
                path = os.path.join(settings.MEDIA_ROOT, 'images/' + image.title)
                size = utils.getImageSize(path)
                # ---------------------------------------------------
                # There is under-age faces    
                data = utils.transformCoordinates(rekog_faces, size[0], size[1])
                if len(data) > 0:
                    print(data)
                    # ---------------------------------------------------
                    context = {'image': image, 'data': data, 'img_width':size[0], 'img_height':size[1]}
                    return render(request, 'detect_faces.html', context)
                else:
                    messages.error(request, "Coordinates transformation error")
            else:
                messages.error(request, "Image does not contains under-age people")
        else:
            messages.error(request, "Image  #_%s_# does not exists" % image.title)
    else:
        messages.error(request, "POST data error")
    
    return redirect('faceApp:index')

# -------------------------------------------------------------------------------------------------------

def detect_blur(request):

    data = list()
    if request.method == "POST":
        # Check if there is any image in DB
        images = Image.objects.all()
        # image = Image.objects.first()
        if images.exists():
            # Fetching the key of the image
            key = utils.getKey(request, 'img_id')
            # ---------------------------------------------------
            # Fetching the image from the database
            image = utils.getImage(key)
            # ---------------------------------------------------
            # Fetching the form data
            data = utils.getData(request, 'coordinate')
            # ---------------------------------------------------
            # Open image file
            img_cv2 = utils.loadImage(image.uploadedImg)
            # ---------------------------------------------------
            # Resize image with fixed height and keeping width
            # aspect-ratio
            img_cv2 = utils.resizeCV2image(img_cv2, 500)
            # ---------------------------------------------------
            try:
                # Setting the coordinate data to send
                data_to_send = []
                # Iterating over each crop coordinates
                for i in range(len(data)):
                    # Getting the rectangle data
                    x, y, w, h = [j for j in data[i]]
                    utils.appendData(data_to_send, i, x, y, w, h)
                    # Setting the 'blur' parameters
                    # Higher 'sigma' >> stronger blur
                    img_cv2 = utils.applyBlur(img_cv2, x, y, w, h, settings.BLUR_SIGMA)
            except Exception as err:
                raise ValueError('<Blur iteration> error: {err}')
            # ---------------------------------------------------
            # Append the '_blurred' subfix to modified image title
            new_title = utils.newTitle(images, image)
            path = os.path.join(settings.MEDIA_ROOT, 'images/' + new_title)
            # Saving the information into the database
            image_blurred = Image(title = new_title, uploadedImg = 'images/' + new_title)
            image_blurred.save()
            # ---------------------------------------------------
            # Saving image to disk
            utils.saveImageToDisk(img_cv2, path)
            # ---------------------------------------------------
            # Render coords. data plus image
            return render(request, 'detect_blur.html', context = {"data": data_to_send, "image": image_blurred})
            # ---------------------------------------------------

            # ---------------------------------------------------
            # Show a message: for debugging only
            # messages.success(request, "<< %s >>" % data_to_send)
            # # Redirect to 'index' only for debugging purpose
            # return redirect('faceApp:index')
            # ---------------------------------------------------
        else:
            raise Http404(f"Error: image not found")
    # Got to the index web and show an error message
    messages.error(request, "POST data error")
    return redirect('faceApp:index')

# -------------------------------------------------------------------------------------------------------
